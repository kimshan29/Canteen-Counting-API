<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['price_admin'] = '10000';
$config['cost_admin'] = '4120';

$config['production'] = false;
$config['server_key'] = 'SB-Mid-server-_BwodAt2CVQTZcV1G1cPwq_W';
$config['do_url'] = 'https://nyc3.digitaloceanspaces.com/dev-space-ngebid/';